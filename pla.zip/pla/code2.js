gdjs.Level2Code = {};
gdjs.Level2Code.localVariables = [];
gdjs.Level2Code.idToCallbackMap = new Map();
gdjs.Level2Code.GDFlyObjects3_1final = [];

gdjs.Level2Code.GDPlayerObjects1_2final = [];

gdjs.Level2Code.GDPlayerObjects2_1final = [];

gdjs.Level2Code.GDPlayerObjects3_1final = [];

gdjs.Level2Code.GDGameOverDialogObjects1= [];
gdjs.Level2Code.GDGameOverDialogObjects2= [];
gdjs.Level2Code.GDGameOverDialogObjects3= [];
gdjs.Level2Code.GDGameOverDialogObjects4= [];
gdjs.Level2Code.GDPlayer2Objects1= [];
gdjs.Level2Code.GDPlayer2Objects2= [];
gdjs.Level2Code.GDPlayer2Objects3= [];
gdjs.Level2Code.GDPlayer2Objects4= [];
gdjs.Level2Code.GDPlatform1Objects1= [];
gdjs.Level2Code.GDPlatform1Objects2= [];
gdjs.Level2Code.GDPlatform1Objects3= [];
gdjs.Level2Code.GDPlatform1Objects4= [];
gdjs.Level2Code.GDPlatform2Objects1= [];
gdjs.Level2Code.GDPlatform2Objects2= [];
gdjs.Level2Code.GDPlatform2Objects3= [];
gdjs.Level2Code.GDPlatform2Objects4= [];
gdjs.Level2Code.GDPlatform3Objects1= [];
gdjs.Level2Code.GDPlatform3Objects2= [];
gdjs.Level2Code.GDPlatform3Objects3= [];
gdjs.Level2Code.GDPlatform3Objects4= [];
gdjs.Level2Code.GDPlatform4Objects1= [];
gdjs.Level2Code.GDPlatform4Objects2= [];
gdjs.Level2Code.GDPlatform4Objects3= [];
gdjs.Level2Code.GDPlatform4Objects4= [];
gdjs.Level2Code.GDPortalObjects1= [];
gdjs.Level2Code.GDPortalObjects2= [];
gdjs.Level2Code.GDPortalObjects3= [];
gdjs.Level2Code.GDPortalObjects4= [];
gdjs.Level2Code.GDCheckpointObjects1= [];
gdjs.Level2Code.GDCheckpointObjects2= [];
gdjs.Level2Code.GDCheckpointObjects3= [];
gdjs.Level2Code.GDCheckpointObjects4= [];
gdjs.Level2Code.GDLadderObjects1= [];
gdjs.Level2Code.GDLadderObjects2= [];
gdjs.Level2Code.GDLadderObjects3= [];
gdjs.Level2Code.GDLadderObjects4= [];
gdjs.Level2Code.GDMonsterObjects1= [];
gdjs.Level2Code.GDMonsterObjects2= [];
gdjs.Level2Code.GDMonsterObjects3= [];
gdjs.Level2Code.GDMonsterObjects4= [];
gdjs.Level2Code.GDFlyObjects1= [];
gdjs.Level2Code.GDFlyObjects2= [];
gdjs.Level2Code.GDFlyObjects3= [];
gdjs.Level2Code.GDFlyObjects4= [];
gdjs.Level2Code.GDCoinObjects1= [];
gdjs.Level2Code.GDCoinObjects2= [];
gdjs.Level2Code.GDCoinObjects3= [];
gdjs.Level2Code.GDCoinObjects4= [];
gdjs.Level2Code.GDMonsterParticlesObjects1= [];
gdjs.Level2Code.GDMonsterParticlesObjects2= [];
gdjs.Level2Code.GDMonsterParticlesObjects3= [];
gdjs.Level2Code.GDMonsterParticlesObjects4= [];
gdjs.Level2Code.GDCoinParticlesObjects1= [];
gdjs.Level2Code.GDCoinParticlesObjects2= [];
gdjs.Level2Code.GDCoinParticlesObjects3= [];
gdjs.Level2Code.GDCoinParticlesObjects4= [];
gdjs.Level2Code.GDDoorParticlesObjects1= [];
gdjs.Level2Code.GDDoorParticlesObjects2= [];
gdjs.Level2Code.GDDoorParticlesObjects3= [];
gdjs.Level2Code.GDDoorParticlesObjects4= [];
gdjs.Level2Code.GDDustParticleObjects1= [];
gdjs.Level2Code.GDDustParticleObjects2= [];
gdjs.Level2Code.GDDustParticleObjects3= [];
gdjs.Level2Code.GDDustParticleObjects4= [];
gdjs.Level2Code.GDCloudsObjects1= [];
gdjs.Level2Code.GDCloudsObjects2= [];
gdjs.Level2Code.GDCloudsObjects3= [];
gdjs.Level2Code.GDCloudsObjects4= [];
gdjs.Level2Code.GDScoreTextObjects1= [];
gdjs.Level2Code.GDScoreTextObjects2= [];
gdjs.Level2Code.GDScoreTextObjects3= [];
gdjs.Level2Code.GDScoreTextObjects4= [];
gdjs.Level2Code.GDBackgroundPlantsObjects1= [];
gdjs.Level2Code.GDBackgroundPlantsObjects2= [];
gdjs.Level2Code.GDBackgroundPlantsObjects3= [];
gdjs.Level2Code.GDBackgroundPlantsObjects4= [];
gdjs.Level2Code.GDLeftBoundaryObjects1= [];
gdjs.Level2Code.GDLeftBoundaryObjects2= [];
gdjs.Level2Code.GDLeftBoundaryObjects3= [];
gdjs.Level2Code.GDLeftBoundaryObjects4= [];
gdjs.Level2Code.GDRightBoundaryObjects1= [];
gdjs.Level2Code.GDRightBoundaryObjects2= [];
gdjs.Level2Code.GDRightBoundaryObjects3= [];
gdjs.Level2Code.GDRightBoundaryObjects4= [];
gdjs.Level2Code.GDTopBoundaryObjects1= [];
gdjs.Level2Code.GDTopBoundaryObjects2= [];
gdjs.Level2Code.GDTopBoundaryObjects3= [];
gdjs.Level2Code.GDTopBoundaryObjects4= [];
gdjs.Level2Code.GDBottomBoundaryObjects1= [];
gdjs.Level2Code.GDBottomBoundaryObjects2= [];
gdjs.Level2Code.GDBottomBoundaryObjects3= [];
gdjs.Level2Code.GDBottomBoundaryObjects4= [];
gdjs.Level2Code.GDBoundaryJumpThroughObjects1= [];
gdjs.Level2Code.GDBoundaryJumpThroughObjects2= [];
gdjs.Level2Code.GDBoundaryJumpThroughObjects3= [];
gdjs.Level2Code.GDBoundaryJumpThroughObjects4= [];
gdjs.Level2Code.GDMoonObjects1= [];
gdjs.Level2Code.GDMoonObjects2= [];
gdjs.Level2Code.GDMoonObjects3= [];
gdjs.Level2Code.GDMoonObjects4= [];
gdjs.Level2Code.GDEndScreenRetryTextObjects1= [];
gdjs.Level2Code.GDEndScreenRetryTextObjects2= [];
gdjs.Level2Code.GDEndScreenRetryTextObjects3= [];
gdjs.Level2Code.GDEndScreenRetryTextObjects4= [];
gdjs.Level2Code.GDJoystickObjects1= [];
gdjs.Level2Code.GDJoystickObjects2= [];
gdjs.Level2Code.GDJoystickObjects3= [];
gdjs.Level2Code.GDJoystickObjects4= [];
gdjs.Level2Code.GDJumpButtonObjects1= [];
gdjs.Level2Code.GDJumpButtonObjects2= [];
gdjs.Level2Code.GDJumpButtonObjects3= [];
gdjs.Level2Code.GDJumpButtonObjects4= [];
gdjs.Level2Code.GDScreenOrientationCheckerObjects1= [];
gdjs.Level2Code.GDScreenOrientationCheckerObjects2= [];
gdjs.Level2Code.GDScreenOrientationCheckerObjects3= [];
gdjs.Level2Code.GDScreenOrientationCheckerObjects4= [];
gdjs.Level2Code.GDFlag_9595RedObjects1= [];
gdjs.Level2Code.GDFlag_9595RedObjects2= [];
gdjs.Level2Code.GDFlag_9595RedObjects3= [];
gdjs.Level2Code.GDFlag_9595RedObjects4= [];
gdjs.Level2Code.GDPlayerObjects1= [];
gdjs.Level2Code.GDPlayerObjects2= [];
gdjs.Level2Code.GDPlayerObjects3= [];
gdjs.Level2Code.GDPlayerObjects4= [];
gdjs.Level2Code.GDStatueObjects1= [];
gdjs.Level2Code.GDStatueObjects2= [];
gdjs.Level2Code.GDStatueObjects3= [];
gdjs.Level2Code.GDStatueObjects4= [];
gdjs.Level2Code.GDSpikesObjects1= [];
gdjs.Level2Code.GDSpikesObjects2= [];
gdjs.Level2Code.GDSpikesObjects3= [];
gdjs.Level2Code.GDSpikesObjects4= [];
gdjs.Level2Code.GDSky2Objects1= [];
gdjs.Level2Code.GDSky2Objects2= [];
gdjs.Level2Code.GDSky2Objects3= [];
gdjs.Level2Code.GDSky2Objects4= [];


gdjs.Level2Code.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Joystick"), gdjs.Level2Code.GDJoystickObjects3);
{for(var i = 0, len = gdjs.Level2Code.GDJoystickObjects3.length ;i < len;++i) {
    gdjs.Level2Code.GDJoystickObjects3[i].hide();
}
}
{for(var i = 0, len = gdjs.Level2Code.GDJoystickObjects3.length ;i < len;++i) {
    gdjs.Level2Code.GDJoystickObjects3[i].ActivateControl(false, null);
}
}
}

}


};gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDJoystickObjects3Objects = Hashtable.newFrom({"Joystick": gdjs.Level2Code.GDJoystickObjects3});
gdjs.Level2Code.eventsList1 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.createObjectsFromExternalLayout(runtimeScene, "Touch controls", 0, 0, 0);
}

{ //Subevents
gdjs.Level2Code.eventsList0(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Joystick"), gdjs.Level2Code.GDJoystickObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__SpriteMultitouchJoystick__HasTouchStartedOnScreenSide.func(runtimeScene, gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDJoystickObjects3Objects, "Left", null);
if (isConditionTrue_0) {
/* Reuse gdjs.Level2Code.GDJoystickObjects3 */
{for(var i = 0, len = gdjs.Level2Code.GDJoystickObjects3.length ;i < len;++i) {
    gdjs.Level2Code.GDJoystickObjects3[i].TeleportAndPress(null);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("JumpButton"), gdjs.Level2Code.GDJumpButtonObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level2Code.GDJumpButtonObjects3.length;i<l;++i) {
    if ( gdjs.Level2Code.GDJumpButtonObjects3[i].getBehavior("MultitouchButton").IsPressed(null) ) {
        isConditionTrue_0 = true;
        gdjs.Level2Code.GDJumpButtonObjects3[k] = gdjs.Level2Code.GDJumpButtonObjects3[i];
        ++k;
    }
}
gdjs.Level2Code.GDJumpButtonObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17535868);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level2Code.GDJumpButtonObjects3 */
{for(var i = 0, len = gdjs.Level2Code.GDJumpButtonObjects3.length ;i < len;++i) {
    gdjs.Level2Code.GDJumpButtonObjects3[i].setColor("74;74;74");
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("JumpButton"), gdjs.Level2Code.GDJumpButtonObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level2Code.GDJumpButtonObjects2.length;i<l;++i) {
    if ( !(gdjs.Level2Code.GDJumpButtonObjects2[i].getBehavior("MultitouchButton").IsPressed(null)) ) {
        isConditionTrue_0 = true;
        gdjs.Level2Code.GDJumpButtonObjects2[k] = gdjs.Level2Code.GDJumpButtonObjects2[i];
        ++k;
    }
}
gdjs.Level2Code.GDJumpButtonObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(13836988);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level2Code.GDJumpButtonObjects2 */
{for(var i = 0, len = gdjs.Level2Code.GDJumpButtonObjects2.length ;i < len;++i) {
    gdjs.Level2Code.GDJumpButtonObjects2[i].setColor("255;255;255");
}
}
}

}


};gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDStatueObjects3Objects = Hashtable.newFrom({"Statue": gdjs.Level2Code.GDStatueObjects3});
gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Level2Code.GDPlayerObjects2});
gdjs.Level2Code.eventsList2 = function(runtimeScene) {
{

let elseEventsChainSatisfied = false;

{

gdjs.copyArray(gdjs.Level2Code.GDPlayerObjects2, gdjs.Level2Code.GDPlayerObjects3);


elseEventsChainSatisfied = false;
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level2Code.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.Level2Code.GDPlayerObjects3[i].getVariableBoolean(gdjs.Level2Code.GDPlayerObjects3[i].getVariables().getFromIndex(1), false, false) ) {
        isConditionTrue_0 = true;
        gdjs.Level2Code.GDPlayerObjects3[k] = gdjs.Level2Code.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.Level2Code.GDPlayerObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Level2Code.GDPlayerObjects3 */
gdjs.Level2Code.GDStatueObjects3.length = 0;

{for(var i = 0, len = gdjs.Level2Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Level2Code.GDPlayerObjects3[i].returnVariable(gdjs.Level2Code.GDPlayerObjects3[i].getVariables().getFromIndex(1)).setBoolean(true);
}
}
{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDStatueObjects3Objects, (( gdjs.Level2Code.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.Level2Code.GDPlayerObjects3[0].getPointX("")), (( gdjs.Level2Code.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.Level2Code.GDPlayerObjects3[0].getPointY("")), "");
}
{for(var i = 0, len = gdjs.Level2Code.GDStatueObjects3.length ;i < len;++i) {
    gdjs.Level2Code.GDStatueObjects3[i].getBehavior("Resizable").setSize((( gdjs.Level2Code.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.Level2Code.GDPlayerObjects3[0].getWidth()), (( gdjs.Level2Code.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.Level2Code.GDPlayerObjects3[0].getHeight()));
}
}
{for(var i = 0, len = gdjs.Level2Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Level2Code.GDPlayerObjects3[i].getBehavior("PlatformerObject").setGravity(99999);
}
}
{for(var i = 0, len = gdjs.Level2Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Level2Code.GDPlayerObjects3[i].getBehavior("PlatformerObject").setJumpSpeed(600);
}
}
{for(var i = 0, len = gdjs.Level2Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Level2Code.GDPlayerObjects3[i].getBehavior("PlatformerObject").setMaxFallingSpeed(600, false);
}
}
{for(var i = 0, len = gdjs.Level2Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Level2Code.GDPlayerObjects3[i].getBehavior("PlatformerObject").setJumpSustainTime(1);
}
}
elseEventsChainSatisfied = true;
}

}


{

/* Reuse gdjs.Level2Code.GDPlayerObjects2 */

if (!elseEventsChainSatisfied) {
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level2Code.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Level2Code.GDPlayerObjects2[i].getVariableBoolean(gdjs.Level2Code.GDPlayerObjects2[i].getVariables().getFromIndex(1), true, false) ) {
        isConditionTrue_0 = true;
        gdjs.Level2Code.GDPlayerObjects2[k] = gdjs.Level2Code.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Level2Code.GDPlayerObjects2.length = k;
if (!elseEventsChainSatisfied && isConditionTrue_0) {
/* Reuse gdjs.Level2Code.GDPlayerObjects2 */
gdjs.copyArray(runtimeScene.getObjects("Statue"), gdjs.Level2Code.GDStatueObjects2);
{for(var i = 0, len = gdjs.Level2Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level2Code.GDPlayerObjects2[i].returnVariable(gdjs.Level2Code.GDPlayerObjects2[i].getVariables().getFromIndex(3)).setNumber((( gdjs.Level2Code.GDStatueObjects2.length === 0 ) ? 0 :gdjs.Level2Code.GDStatueObjects2[0].getAngleToObject(gdjs.Level2Code.GDPlayerObjects2[i])));
}
}
{for(var i = 0, len = gdjs.Level2Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level2Code.GDPlayerObjects2[i].returnVariable(gdjs.Level2Code.GDPlayerObjects2[i].getVariables().getFromIndex(4)).setNumber((( gdjs.Level2Code.GDStatueObjects2.length === 0 ) ? 0 :gdjs.Level2Code.GDStatueObjects2[0].getDistanceToObject(gdjs.Level2Code.GDPlayerObjects2[i])));
}
}
{for(var i = 0, len = gdjs.Level2Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level2Code.GDPlayerObjects2[i].getBehavior("PlatformerObject").setGravity(1000);
}
}
{for(var i = 0, len = gdjs.Level2Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level2Code.GDPlayerObjects2[i].getBehavior("PlatformerObject").setJumpSustainTime(0.2);
}
}
{for(var i = 0, len = gdjs.Level2Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level2Code.GDPlayerObjects2[i].setPosition((( gdjs.Level2Code.GDStatueObjects2.length === 0 ) ? 0 :gdjs.Level2Code.GDStatueObjects2[0].getCenterXInScene()),(( gdjs.Level2Code.GDStatueObjects2.length === 0 ) ? 0 :gdjs.Level2Code.GDStatueObjects2[0].getCenterYInScene()));
}
}
{for(var i = 0, len = gdjs.Level2Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level2Code.GDPlayerObjects2[i].setY(gdjs.Level2Code.GDPlayerObjects2[i].getY() - (50));
}
}
{for(var i = 0, len = gdjs.Level2Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level2Code.GDPlayerObjects2[i].getBehavior("PlatformerObject").setMaxSpeed(999999999999999999999999);
}
}
{for(var i = 0, len = gdjs.Level2Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level2Code.GDPlayerObjects2[i].getBehavior("PlatformerObject").setDeceleration(0);
}
}
{for(var i = 0, len = gdjs.Level2Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level2Code.GDPlayerObjects2[i].getBehavior("PlatformerObject").setMaxFallingSpeed(99999999999999999, false);
}
}
{for(var i = 0, len = gdjs.Level2Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level2Code.GDPlayerObjects2[i].getBehavior("PlatformerObject").setCurrentSpeed(2 * gdjs.evtTools.common.getXFromAngleAndDistance(gdjs.Level2Code.GDPlayerObjects2[i].getVariables().getFromIndex(3).getAsNumber(), gdjs.Level2Code.GDPlayerObjects2[i].getVariables().getFromIndex(4).getAsNumber()));
}
}
{for(var i = 0, len = gdjs.Level2Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level2Code.GDPlayerObjects2[i].getBehavior("PlatformerObject").setJumpSpeed(((Math.abs(3 * gdjs.evtTools.common.getYFromAngleAndDistance(gdjs.Level2Code.GDPlayerObjects2[i].getVariables().getFromIndex(3).getAsNumber(), gdjs.Level2Code.GDPlayerObjects2[i].getVariables().getFromIndex(4).getAsNumber())) - 3 * gdjs.evtTools.common.getYFromAngleAndDistance(gdjs.Level2Code.GDPlayerObjects2[i].getVariables().getFromIndex(3).getAsNumber(), gdjs.Level2Code.GDPlayerObjects2[i].getVariables().getFromIndex(4).getAsNumber()))) / 2 + 650);
}
}
{gdjs.evtsExt__Player__Bounce.func(runtimeScene, gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDPlayerObjects2Objects, "PlatformerObject", null);
}
{for(var i = 0, len = gdjs.Level2Code.GDStatueObjects2.length ;i < len;++i) {
    gdjs.Level2Code.GDStatueObjects2[i].deleteFromScene(runtimeScene);
}
}
{for(var i = 0, len = gdjs.Level2Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level2Code.GDPlayerObjects2[i].getBehavior("PlatformerObject").setAcceleration(0);
}
}
{for(var i = 0, len = gdjs.Level2Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level2Code.GDPlayerObjects2[i].returnVariable(gdjs.Level2Code.GDPlayerObjects2[i].getVariables().getFromIndex(1)).setBoolean(false);
}
}
{for(var i = 0, len = gdjs.Level2Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level2Code.GDPlayerObjects2[i].resetTimer("minFly");
}
}
{for(var i = 0, len = gdjs.Level2Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level2Code.GDPlayerObjects2[i].unpauseTimer("minFly");
}
}
{for(var i = 0, len = gdjs.Level2Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level2Code.GDPlayerObjects2[i].returnVariable(gdjs.Level2Code.GDPlayerObjects2[i].getVariables().getFromIndex(2)).setNumber(1);
}
}
elseEventsChainSatisfied = true;
}
}

}

}

};gdjs.Level2Code.eventsList3 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.systemInfo.hasTouchScreen(runtimeScene);
if (isConditionTrue_0) {

{ //Subevents
gdjs.Level2Code.eventsList1(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level2Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "e");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level2Code.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Level2Code.GDPlayerObjects2[i].getVariableNumber(gdjs.Level2Code.GDPlayerObjects2[i].getVariables().getFromIndex(2)) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.Level2Code.GDPlayerObjects2[k] = gdjs.Level2Code.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Level2Code.GDPlayerObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(12219204);
}
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Level2Code.eventsList2(runtimeScene);} //End of subevents
}

}


{

gdjs.Level2Code.GDPlayerObjects1.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
{gdjs.Level2Code.GDPlayerObjects1_2final.length = 0;
let isConditionTrue_2 = false;
isConditionTrue_1 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level2Code.GDPlayerObjects2);
for (var i = 0, k = 0, l = gdjs.Level2Code.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Level2Code.GDPlayerObjects2[i].getBehavior("PlatformerObject").isOnLadder() ) {
        isConditionTrue_2 = true;
        gdjs.Level2Code.GDPlayerObjects2[k] = gdjs.Level2Code.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Level2Code.GDPlayerObjects2.length = k;
if(isConditionTrue_2) {
    isConditionTrue_1 = true;
    for (let j = 0, jLen = gdjs.Level2Code.GDPlayerObjects2.length; j < jLen ; ++j) {
        if ( gdjs.Level2Code.GDPlayerObjects1_2final.indexOf(gdjs.Level2Code.GDPlayerObjects2[j]) === -1 )
            gdjs.Level2Code.GDPlayerObjects1_2final.push(gdjs.Level2Code.GDPlayerObjects2[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level2Code.GDPlayerObjects2);
for (var i = 0, k = 0, l = gdjs.Level2Code.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Level2Code.GDPlayerObjects2[i].getBehavior("PlatformerObject").isOnFloor() ) {
        isConditionTrue_2 = true;
        gdjs.Level2Code.GDPlayerObjects2[k] = gdjs.Level2Code.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Level2Code.GDPlayerObjects2.length = k;
if(isConditionTrue_2) {
    isConditionTrue_1 = true;
    for (let j = 0, jLen = gdjs.Level2Code.GDPlayerObjects2.length; j < jLen ; ++j) {
        if ( gdjs.Level2Code.GDPlayerObjects1_2final.indexOf(gdjs.Level2Code.GDPlayerObjects2[j]) === -1 )
            gdjs.Level2Code.GDPlayerObjects1_2final.push(gdjs.Level2Code.GDPlayerObjects2[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Level2Code.GDPlayerObjects1_2final, gdjs.Level2Code.GDPlayerObjects1);
}
}
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Level2Code.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.Level2Code.GDPlayerObjects1[i].getTimerElapsedTimeInSecondsOrNaN("minFly") >= 0.2 ) {
        isConditionTrue_1 = true;
        gdjs.Level2Code.GDPlayerObjects1[k] = gdjs.Level2Code.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.Level2Code.GDPlayerObjects1.length = k;
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level2Code.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.Level2Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Level2Code.GDPlayerObjects1[i].getBehavior("PlatformerObject").setDeceleration(1125);
}
}
{for(var i = 0, len = gdjs.Level2Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Level2Code.GDPlayerObjects1[i].getBehavior("PlatformerObject").setJumpSpeed(650);
}
}
{for(var i = 0, len = gdjs.Level2Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Level2Code.GDPlayerObjects1[i].getBehavior("PlatformerObject").setMaxSpeed(200);
}
}
{for(var i = 0, len = gdjs.Level2Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Level2Code.GDPlayerObjects1[i].getBehavior("PlatformerObject").setAcceleration(1125);
}
}
{for(var i = 0, len = gdjs.Level2Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Level2Code.GDPlayerObjects1[i].getBehavior("PlatformerObject").setMaxFallingSpeed(500, false);
}
}
{for(var i = 0, len = gdjs.Level2Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Level2Code.GDPlayerObjects1[i].pauseTimer("minFly");
}
}
{for(var i = 0, len = gdjs.Level2Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Level2Code.GDPlayerObjects1[i].resetTimer("minFly");
}
}
{for(var i = 0, len = gdjs.Level2Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Level2Code.GDPlayerObjects1[i].returnVariable(gdjs.Level2Code.GDPlayerObjects1[i].getVariables().getFromIndex(2)).setNumber(0);
}
}
}

}


};gdjs.Level2Code.eventsList4 = function(runtimeScene) {

{


gdjs.Level2Code.eventsList3(runtimeScene);
}


};gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Level2Code.GDPlayerObjects2});
gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDDustParticleObjects2Objects = Hashtable.newFrom({"DustParticle": gdjs.Level2Code.GDDustParticleObjects2});
gdjs.Level2Code.eventsList5 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level2Code.GDPlayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level2Code.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.Level2Code.GDPlayerObjects3[i].getBehavior("PlatformerObject").isJumping() ) {
        isConditionTrue_0 = true;
        gdjs.Level2Code.GDPlayerObjects3[k] = gdjs.Level2Code.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.Level2Code.GDPlayerObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(11467796);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "jump.mp3", false, 50, 1);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level2Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__Player__IsSteppingOnFloor.func(runtimeScene, gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDPlayerObjects2Objects, "PlatformerObject", null);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(23088876);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level2Code.GDPlayerObjects2 */
gdjs.Level2Code.GDDustParticleObjects2.length = 0;

{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "assets/audio/grass.mp3", 1, false, 20, gdjs.randomFloatInRange(0.7, 1.2));
}
{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDDustParticleObjects2Objects, (( gdjs.Level2Code.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.Level2Code.GDPlayerObjects2[0].getAABBCenterX()), (( gdjs.Level2Code.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.Level2Code.GDPlayerObjects2[0].getAABBBottom()), "");
}
{for(var i = 0, len = gdjs.Level2Code.GDDustParticleObjects2.length ;i < len;++i) {
    gdjs.Level2Code.GDDustParticleObjects2[i].setZOrder(-1);
}
}
{for(var i = 0, len = gdjs.Level2Code.GDDustParticleObjects2.length ;i < len;++i) {
    gdjs.Level2Code.GDDustParticleObjects2[i].setAngle(270);
}
}
}

}


};gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.Level2Code.GDPlayerObjects3});
gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Level2Code.GDPlayerObjects2});
gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDCheckpointObjects2Objects = Hashtable.newFrom({"Checkpoint": gdjs.Level2Code.GDCheckpointObjects2});
gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDCheckpointObjects3Objects = Hashtable.newFrom({"Checkpoint": gdjs.Level2Code.GDCheckpointObjects3});
gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Level2Code.GDPlayerObjects2});
gdjs.Level2Code.eventsList6 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.Level2Code.GDCheckpointObjects2, gdjs.Level2Code.GDCheckpointObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.pickAllObjects(runtimeScene, gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDCheckpointObjects3Objects);
if (isConditionTrue_0) {
/* Reuse gdjs.Level2Code.GDCheckpointObjects3 */
{for(var i = 0, len = gdjs.Level2Code.GDCheckpointObjects3.length ;i < len;++i) {
    gdjs.Level2Code.GDCheckpointObjects3[i].getBehavior("Animation").setAnimationName("InActive");
}
}
}

}


{


let isConditionTrue_0 = false;
{
/* Reuse gdjs.Level2Code.GDCheckpointObjects2 */
/* Reuse gdjs.Level2Code.GDPlayerObjects2 */
{gdjs.evtsExt__Checkpoints__SaveCheckpoint.func(runtimeScene, gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDPlayerObjects2Objects, (( gdjs.Level2Code.GDCheckpointObjects2.length === 0 ) ? 0 :gdjs.Level2Code.GDCheckpointObjects2[0].getPointX("")), (( gdjs.Level2Code.GDCheckpointObjects2.length === 0 ) ? 0 :gdjs.Level2Code.GDCheckpointObjects2[0].getPointY("")), "Checkpoint", null);
}
{for(var i = 0, len = gdjs.Level2Code.GDCheckpointObjects2.length ;i < len;++i) {
    gdjs.Level2Code.GDCheckpointObjects2[i].getBehavior("Animation").setAnimationName("Activate");
}
}
}

}


};gdjs.Level2Code.eventsList7 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level2Code.GDPlayerObjects3);
{gdjs.evtsExt__Checkpoints__SaveCheckpoint.func(runtimeScene, gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDPlayerObjects3Objects, (( gdjs.Level2Code.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.Level2Code.GDPlayerObjects3[0].getPointX("")), (( gdjs.Level2Code.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.Level2Code.GDPlayerObjects3[0].getPointY("")), "Checkpoint", null);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Checkpoint"), gdjs.Level2Code.GDCheckpointObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level2Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDPlayerObjects2Objects, gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDCheckpointObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level2Code.GDCheckpointObjects2.length;i<l;++i) {
    if ( !(gdjs.Level2Code.GDCheckpointObjects2[i].getBehavior("Animation").getAnimationName() == "Activate") ) {
        isConditionTrue_0 = true;
        gdjs.Level2Code.GDCheckpointObjects2[k] = gdjs.Level2Code.GDCheckpointObjects2[i];
        ++k;
    }
}
gdjs.Level2Code.GDCheckpointObjects2.length = k;
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "checkpoint.mp3", false, 50, 1);
}

{ //Subevents
gdjs.Level2Code.eventsList6(runtimeScene);} //End of subevents
}

}


};gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Level2Code.GDPlayerObjects2});
gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDCoinObjects2Objects = Hashtable.newFrom({"Coin": gdjs.Level2Code.GDCoinObjects2});
gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDCoinParticlesObjects2Objects = Hashtable.newFrom({"CoinParticles": gdjs.Level2Code.GDCoinParticlesObjects2});
gdjs.Level2Code.eventsList8 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Coin"), gdjs.Level2Code.GDCoinObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level2Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDPlayerObjects2Objects, gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDCoinObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Level2Code.GDCoinObjects2 */
gdjs.Level2Code.GDCoinParticlesObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDCoinParticlesObjects2Objects, (( gdjs.Level2Code.GDCoinObjects2.length === 0 ) ? 0 :gdjs.Level2Code.GDCoinObjects2[0].getCenterXInScene()), (( gdjs.Level2Code.GDCoinObjects2.length === 0 ) ? 0 :gdjs.Level2Code.GDCoinObjects2[0].getCenterYInScene()), "");
}
{for(var i = 0, len = gdjs.Level2Code.GDCoinObjects2.length ;i < len;++i) {
    gdjs.Level2Code.GDCoinObjects2[i].deleteFromScene(runtimeScene);
}
}
{runtimeScene.getScene().getVariables().getFromIndex(0).add(100);
}
{gdjs.evtTools.sound.playSound(runtimeScene, "coin.mp3", false, 50, 1);
}
}

}


};gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Level2Code.GDPlayerObjects2});
gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.Level2Code.GDPlayerObjects1});
gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDSpikesObjects1Objects = Hashtable.newFrom({"Spikes": gdjs.Level2Code.GDSpikesObjects1});
gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.Level2Code.GDPlayerObjects1});
gdjs.Level2Code.eventsList9 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level2Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level2Code.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Level2Code.GDPlayerObjects2[i].getY() > gdjs.evtTools.camera.getCameraBorderBottom(runtimeScene, "", 0) ) {
        isConditionTrue_0 = true;
        gdjs.Level2Code.GDPlayerObjects2[k] = gdjs.Level2Code.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Level2Code.GDPlayerObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Level2Code.GDPlayerObjects2 */
gdjs.copyArray(runtimeScene.getObjects("Statue"), gdjs.Level2Code.GDStatueObjects2);
{gdjs.evtsExt__Player__TriggerDeath.func(runtimeScene, gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDPlayerObjects2Objects, null);
}
{for(var i = 0, len = gdjs.Level2Code.GDStatueObjects2.length ;i < len;++i) {
    gdjs.Level2Code.GDStatueObjects2[i].deleteFromScene(runtimeScene);
}
}
{for(var i = 0, len = gdjs.Level2Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level2Code.GDPlayerObjects2[i].returnVariable(gdjs.Level2Code.GDPlayerObjects2[i].getVariables().getFromIndex(1)).setBoolean(false);
}
}
{for(var i = 0, len = gdjs.Level2Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level2Code.GDPlayerObjects2[i].getBehavior("PlatformerObject").setMaxFallingSpeed(500, false);
}
}
{for(var i = 0, len = gdjs.Level2Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level2Code.GDPlayerObjects2[i].getBehavior("PlatformerObject").setGravity(1000);
}
}
{for(var i = 0, len = gdjs.Level2Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level2Code.GDPlayerObjects2[i].getBehavior("PlatformerObject").setJumpSpeed(650);
}
}
{for(var i = 0, len = gdjs.Level2Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level2Code.GDPlayerObjects2[i].getBehavior("PlatformerObject").setJumpSustainTime(0.2);
}
}
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Level2", true);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level2Code.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("Spikes"), gdjs.Level2Code.GDSpikesObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDPlayerObjects1Objects, gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDSpikesObjects1Objects, false, runtimeScene, true);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level2Code.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.Level2Code.GDPlayerObjects1[i].getVariableBoolean(gdjs.Level2Code.GDPlayerObjects1[i].getVariables().getFromIndex(1), false, false) ) {
        isConditionTrue_0 = true;
        gdjs.Level2Code.GDPlayerObjects1[k] = gdjs.Level2Code.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.Level2Code.GDPlayerObjects1.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level2Code.GDPlayerObjects1 */
gdjs.copyArray(runtimeScene.getObjects("Statue"), gdjs.Level2Code.GDStatueObjects1);
{gdjs.evtsExt__Player__TriggerDeath.func(runtimeScene, gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDPlayerObjects1Objects, null);
}
{for(var i = 0, len = gdjs.Level2Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Level2Code.GDPlayerObjects1[i].getBehavior("PlatformerObject").setJumpSustainTime(0.2);
}
}
{for(var i = 0, len = gdjs.Level2Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Level2Code.GDPlayerObjects1[i].getBehavior("PlatformerObject").setJumpSpeed(650);
}
}
{for(var i = 0, len = gdjs.Level2Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Level2Code.GDPlayerObjects1[i].getBehavior("PlatformerObject").setGravity(1000);
}
}
{for(var i = 0, len = gdjs.Level2Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Level2Code.GDPlayerObjects1[i].getBehavior("PlatformerObject").setMaxFallingSpeed(500, false);
}
}
{for(var i = 0, len = gdjs.Level2Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Level2Code.GDPlayerObjects1[i].returnVariable(gdjs.Level2Code.GDPlayerObjects1[i].getVariables().getFromIndex(1)).setBoolean(false);
}
}
{for(var i = 0, len = gdjs.Level2Code.GDStatueObjects1.length ;i < len;++i) {
    gdjs.Level2Code.GDStatueObjects1[i].deleteFromScene(runtimeScene);
}
}
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Level2", true);
}
}

}


};gdjs.Level2Code.eventsList10 = function(runtimeScene) {

{


gdjs.Level2Code.eventsList5(runtimeScene);
}


{


gdjs.Level2Code.eventsList7(runtimeScene);
}


{


gdjs.Level2Code.eventsList8(runtimeScene);
}


{


gdjs.Level2Code.eventsList9(runtimeScene);
}


};gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDFlyObjects2Objects = Hashtable.newFrom({"Fly": gdjs.Level2Code.GDFlyObjects2});
gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Level2Code.GDPlayerObjects2});
gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDFlyObjects2Objects = Hashtable.newFrom({"Fly": gdjs.Level2Code.GDFlyObjects2});
gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDFlyObjects3Objects = Hashtable.newFrom({"Fly": gdjs.Level2Code.GDFlyObjects3});
gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.Level2Code.GDPlayerObjects3});
gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Level2Code.GDPlayerObjects2});
gdjs.Level2Code.eventsList11 = function(runtimeScene) {
{

let elseEventsChainSatisfied = false;

{

gdjs.copyArray(gdjs.Level2Code.GDFlyObjects2, gdjs.Level2Code.GDFlyObjects3);

gdjs.copyArray(gdjs.Level2Code.GDPlayerObjects2, gdjs.Level2Code.GDPlayerObjects3);


elseEventsChainSatisfied = false;
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.Level2Code.GDFlyObjects3_1final.length = 0;
gdjs.Level2Code.GDPlayerObjects3_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.Level2Code.GDFlyObjects2, gdjs.Level2Code.GDFlyObjects4);

gdjs.copyArray(gdjs.Level2Code.GDPlayerObjects2, gdjs.Level2Code.GDPlayerObjects4);

{let isConditionTrue_2 = false;
isConditionTrue_2 = false;
for (var i = 0, k = 0, l = gdjs.Level2Code.GDPlayerObjects4.length;i<l;++i) {
    if ( gdjs.Level2Code.GDPlayerObjects4[i].getVariableBoolean(gdjs.Level2Code.GDPlayerObjects4[i].getVariables().getFromIndex(1), true, false) ) {
        isConditionTrue_2 = true;
        gdjs.Level2Code.GDPlayerObjects4[k] = gdjs.Level2Code.GDPlayerObjects4[i];
        ++k;
    }
}
gdjs.Level2Code.GDPlayerObjects4.length = k;
if (isConditionTrue_2) {
isConditionTrue_2 = false;
{isConditionTrue_2 = ((( gdjs.Level2Code.GDFlyObjects4.length === 0 ) ? 0 :gdjs.Level2Code.GDFlyObjects4[0].getAABBTop()) + (( gdjs.Level2Code.GDFlyObjects4.length === 0 ) ? 0 :gdjs.Level2Code.GDFlyObjects4[0].getCenterYInScene()) > (( gdjs.Level2Code.GDPlayerObjects4.length === 0 ) ? 0 :gdjs.Level2Code.GDPlayerObjects4[0].getAABBBottom()) + (( gdjs.Level2Code.GDPlayerObjects4.length === 0 ) ? 0 :gdjs.Level2Code.GDPlayerObjects4[0].getCenterYInScene()) + 1);
}
}
isConditionTrue_1 = isConditionTrue_2;
}
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Level2Code.GDFlyObjects4.length; j < jLen ; ++j) {
        if ( gdjs.Level2Code.GDFlyObjects3_1final.indexOf(gdjs.Level2Code.GDFlyObjects4[j]) === -1 )
            gdjs.Level2Code.GDFlyObjects3_1final.push(gdjs.Level2Code.GDFlyObjects4[j]);
    }
    for (let j = 0, jLen = gdjs.Level2Code.GDPlayerObjects4.length; j < jLen ; ++j) {
        if ( gdjs.Level2Code.GDPlayerObjects3_1final.indexOf(gdjs.Level2Code.GDPlayerObjects4[j]) === -1 )
            gdjs.Level2Code.GDPlayerObjects3_1final.push(gdjs.Level2Code.GDPlayerObjects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Level2Code.GDPlayerObjects2, gdjs.Level2Code.GDPlayerObjects4);

{let isConditionTrue_2 = false;
isConditionTrue_2 = false;
for (var i = 0, k = 0, l = gdjs.Level2Code.GDPlayerObjects4.length;i<l;++i) {
    if ( gdjs.Level2Code.GDPlayerObjects4[i].getBehavior("PlatformerObject").isFalling() ) {
        isConditionTrue_2 = true;
        gdjs.Level2Code.GDPlayerObjects4[k] = gdjs.Level2Code.GDPlayerObjects4[i];
        ++k;
    }
}
gdjs.Level2Code.GDPlayerObjects4.length = k;
if (isConditionTrue_2) {
isConditionTrue_2 = false;
for (var i = 0, k = 0, l = gdjs.Level2Code.GDPlayerObjects4.length;i<l;++i) {
    if ( gdjs.Level2Code.GDPlayerObjects4[i].getVariableBoolean(gdjs.Level2Code.GDPlayerObjects4[i].getVariables().getFromIndex(1), false, false) ) {
        isConditionTrue_2 = true;
        gdjs.Level2Code.GDPlayerObjects4[k] = gdjs.Level2Code.GDPlayerObjects4[i];
        ++k;
    }
}
gdjs.Level2Code.GDPlayerObjects4.length = k;
}
isConditionTrue_1 = isConditionTrue_2;
}
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Level2Code.GDPlayerObjects4.length; j < jLen ; ++j) {
        if ( gdjs.Level2Code.GDPlayerObjects3_1final.indexOf(gdjs.Level2Code.GDPlayerObjects4[j]) === -1 )
            gdjs.Level2Code.GDPlayerObjects3_1final.push(gdjs.Level2Code.GDPlayerObjects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Level2Code.GDFlyObjects3_1final, gdjs.Level2Code.GDFlyObjects3);
gdjs.copyArray(gdjs.Level2Code.GDPlayerObjects3_1final, gdjs.Level2Code.GDPlayerObjects3);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level2Code.GDFlyObjects3 */
/* Reuse gdjs.Level2Code.GDPlayerObjects3 */
{gdjs.evtsExt__Enemy__TriggerFlyDeath.func(runtimeScene, gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDFlyObjects3Objects, "RectangleMovement", "ShakeObject_PositionAngle", null);
}
{gdjs.evtsExt__Player__Bounce.func(runtimeScene, gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDPlayerObjects3Objects, "PlatformerObject", null);
}
{runtimeScene.getScene().getVariables().getFromIndex(0).add(50);
}
elseEventsChainSatisfied = true;
}

}


{


if (!elseEventsChainSatisfied) {
let isConditionTrue_0 = false;
if (!elseEventsChainSatisfied) {
/* Reuse gdjs.Level2Code.GDPlayerObjects2 */
gdjs.copyArray(runtimeScene.getObjects("Statue"), gdjs.Level2Code.GDStatueObjects2);
{gdjs.evtsExt__Player__TriggerDeath.func(runtimeScene, gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDPlayerObjects2Objects, null);
}
{for(var i = 0, len = gdjs.Level2Code.GDStatueObjects2.length ;i < len;++i) {
    gdjs.Level2Code.GDStatueObjects2[i].deleteFromScene(runtimeScene);
}
}
{for(var i = 0, len = gdjs.Level2Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level2Code.GDPlayerObjects2[i].returnVariable(gdjs.Level2Code.GDPlayerObjects2[i].getVariables().getFromIndex(1)).setBoolean(false);
}
}
{for(var i = 0, len = gdjs.Level2Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level2Code.GDPlayerObjects2[i].getBehavior("PlatformerObject").setMaxFallingSpeed(500, false);
}
}
{for(var i = 0, len = gdjs.Level2Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level2Code.GDPlayerObjects2[i].getBehavior("PlatformerObject").setGravity(1000);
}
}
{for(var i = 0, len = gdjs.Level2Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level2Code.GDPlayerObjects2[i].getBehavior("PlatformerObject").setJumpSpeed(650);
}
}
{for(var i = 0, len = gdjs.Level2Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level2Code.GDPlayerObjects2[i].getBehavior("PlatformerObject").setJumpSustainTime(0.2);
}
}
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Level2", true);
}
elseEventsChainSatisfied = true;
}
}

}

}

};gdjs.Level2Code.eventsList12 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Fly"), gdjs.Level2Code.GDFlyObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level2Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtsExt__Enemy__IsFlyDead.func(runtimeScene, gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDFlyObjects2Objects, null));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDPlayerObjects2Objects, gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDFlyObjects2Objects, false, runtimeScene, false);
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Level2Code.eventsList11(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("BackgroundPlants"), gdjs.Level2Code.GDBackgroundPlantsObjects1);
gdjs.copyArray(runtimeScene.getObjects("Fly"), gdjs.Level2Code.GDFlyObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level2Code.GDFlyObjects1.length;i<l;++i) {
    if ( gdjs.Level2Code.GDFlyObjects1[i].getY() > (( gdjs.Level2Code.GDBackgroundPlantsObjects1.length === 0 ) ? 0 :gdjs.Level2Code.GDBackgroundPlantsObjects1[0].getAABBBottom()) ) {
        isConditionTrue_0 = true;
        gdjs.Level2Code.GDFlyObjects1[k] = gdjs.Level2Code.GDFlyObjects1[i];
        ++k;
    }
}
gdjs.Level2Code.GDFlyObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Level2Code.GDFlyObjects1 */
{for(var i = 0, len = gdjs.Level2Code.GDFlyObjects1.length ;i < len;++i) {
    gdjs.Level2Code.GDFlyObjects1[i].deleteFromScene(runtimeScene);
}
}
}

}


};gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.Level2Code.GDPlayerObjects1});
gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDMonsterObjects1Objects = Hashtable.newFrom({"Monster": gdjs.Level2Code.GDMonsterObjects1});
gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Level2Code.GDPlayerObjects2});
gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDMonsterParticlesObjects2Objects = Hashtable.newFrom({"MonsterParticles": gdjs.Level2Code.GDMonsterParticlesObjects2});
gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Level2Code.GDPlayerObjects2});
gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.Level2Code.GDPlayerObjects1});
gdjs.Level2Code.eventsList13 = function(runtimeScene) {
{

let elseEventsChainSatisfied = false;

{

gdjs.copyArray(gdjs.Level2Code.GDPlayerObjects1, gdjs.Level2Code.GDPlayerObjects2);


elseEventsChainSatisfied = false;
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.Level2Code.GDPlayerObjects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.Level2Code.GDPlayerObjects1, gdjs.Level2Code.GDPlayerObjects3);

for (var i = 0, k = 0, l = gdjs.Level2Code.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.Level2Code.GDPlayerObjects3[i].getBehavior("PlatformerObject").isFalling() ) {
        isConditionTrue_1 = true;
        gdjs.Level2Code.GDPlayerObjects3[k] = gdjs.Level2Code.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.Level2Code.GDPlayerObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Level2Code.GDPlayerObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Level2Code.GDPlayerObjects2_1final.indexOf(gdjs.Level2Code.GDPlayerObjects3[j]) === -1 )
            gdjs.Level2Code.GDPlayerObjects2_1final.push(gdjs.Level2Code.GDPlayerObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Level2Code.GDPlayerObjects1, gdjs.Level2Code.GDPlayerObjects3);

for (var i = 0, k = 0, l = gdjs.Level2Code.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.Level2Code.GDPlayerObjects3[i].getVariableBoolean(gdjs.Level2Code.GDPlayerObjects3[i].getVariables().getFromIndex(1), true, false) ) {
        isConditionTrue_1 = true;
        gdjs.Level2Code.GDPlayerObjects3[k] = gdjs.Level2Code.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.Level2Code.GDPlayerObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Level2Code.GDPlayerObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Level2Code.GDPlayerObjects2_1final.indexOf(gdjs.Level2Code.GDPlayerObjects3[j]) === -1 )
            gdjs.Level2Code.GDPlayerObjects2_1final.push(gdjs.Level2Code.GDPlayerObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Level2Code.GDPlayerObjects2_1final, gdjs.Level2Code.GDPlayerObjects2);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.Level2Code.GDMonsterObjects1, gdjs.Level2Code.GDMonsterObjects2);

/* Reuse gdjs.Level2Code.GDPlayerObjects2 */
gdjs.Level2Code.GDMonsterParticlesObjects2.length = 0;

{for(var i = 0, len = gdjs.Level2Code.GDMonsterObjects2.length ;i < len;++i) {
    gdjs.Level2Code.GDMonsterObjects2[i].deleteFromScene(runtimeScene);
}
}
{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDMonsterParticlesObjects2Objects, (( gdjs.Level2Code.GDMonsterObjects2.length === 0 ) ? 0 :gdjs.Level2Code.GDMonsterObjects2[0].getCenterXInScene()), (( gdjs.Level2Code.GDMonsterObjects2.length === 0 ) ? 0 :gdjs.Level2Code.GDMonsterObjects2[0].getCenterYInScene()), "");
}
{gdjs.evtsExt__Player__Bounce.func(runtimeScene, gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDPlayerObjects2Objects, "PlatformerObject", null);
}
{runtimeScene.getScene().getVariables().getFromIndex(0).add(50);
}
elseEventsChainSatisfied = true;
}

}


{


if (!elseEventsChainSatisfied) {
let isConditionTrue_0 = false;
if (!elseEventsChainSatisfied) {
/* Reuse gdjs.Level2Code.GDPlayerObjects1 */
gdjs.copyArray(runtimeScene.getObjects("Statue"), gdjs.Level2Code.GDStatueObjects1);
{gdjs.evtsExt__Player__TriggerDeath.func(runtimeScene, gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDPlayerObjects1Objects, null);
}
{for(var i = 0, len = gdjs.Level2Code.GDStatueObjects1.length ;i < len;++i) {
    gdjs.Level2Code.GDStatueObjects1[i].deleteFromScene(runtimeScene);
}
}
{for(var i = 0, len = gdjs.Level2Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Level2Code.GDPlayerObjects1[i].returnVariable(gdjs.Level2Code.GDPlayerObjects1[i].getVariables().getFromIndex(1)).setBoolean(false);
}
}
{for(var i = 0, len = gdjs.Level2Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Level2Code.GDPlayerObjects1[i].getBehavior("PlatformerObject").setMaxFallingSpeed(500, false);
}
}
{for(var i = 0, len = gdjs.Level2Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Level2Code.GDPlayerObjects1[i].getBehavior("PlatformerObject").setGravity(1000);
}
}
{for(var i = 0, len = gdjs.Level2Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Level2Code.GDPlayerObjects1[i].getBehavior("PlatformerObject").setJumpSpeed(650);
}
}
{for(var i = 0, len = gdjs.Level2Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Level2Code.GDPlayerObjects1[i].getBehavior("PlatformerObject").setJumpSustainTime(0.2);
}
}
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Level2", true);
}
elseEventsChainSatisfied = true;
}
}

}

}

};gdjs.Level2Code.eventsList14 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.Level2Code.GDMonsterObjects1, gdjs.Level2Code.GDMonsterObjects2);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level2Code.GDMonsterObjects2.length;i<l;++i) {
    if ( gdjs.Level2Code.GDMonsterObjects2[i].getBehavior("MonsterEnemy").IsOnFire(null) ) {
        isConditionTrue_0 = true;
        gdjs.Level2Code.GDMonsterObjects2[k] = gdjs.Level2Code.GDMonsterObjects2[i];
        ++k;
    }
}
gdjs.Level2Code.GDMonsterObjects2.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.Level2Code.GDPlayerObjects1, gdjs.Level2Code.GDPlayerObjects2);

gdjs.copyArray(runtimeScene.getObjects("Statue"), gdjs.Level2Code.GDStatueObjects2);
{gdjs.evtsExt__Player__TriggerDeath.func(runtimeScene, gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDPlayerObjects2Objects, null);
}
{for(var i = 0, len = gdjs.Level2Code.GDStatueObjects2.length ;i < len;++i) {
    gdjs.Level2Code.GDStatueObjects2[i].deleteFromScene(runtimeScene);
}
}
{for(var i = 0, len = gdjs.Level2Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level2Code.GDPlayerObjects2[i].returnVariable(gdjs.Level2Code.GDPlayerObjects2[i].getVariables().getFromIndex(1)).setBoolean(false);
}
}
{for(var i = 0, len = gdjs.Level2Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level2Code.GDPlayerObjects2[i].getBehavior("PlatformerObject").setMaxFallingSpeed(500, false);
}
}
{for(var i = 0, len = gdjs.Level2Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level2Code.GDPlayerObjects2[i].getBehavior("PlatformerObject").setGravity(1000);
}
}
{for(var i = 0, len = gdjs.Level2Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level2Code.GDPlayerObjects2[i].getBehavior("PlatformerObject").setJumpSpeed(650);
}
}
{for(var i = 0, len = gdjs.Level2Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level2Code.GDPlayerObjects2[i].getBehavior("PlatformerObject").setJumpSustainTime(0.2);
}
}
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Level2", true);
}
}

}


{

/* Reuse gdjs.Level2Code.GDMonsterObjects1 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level2Code.GDMonsterObjects1.length;i<l;++i) {
    if ( !(gdjs.Level2Code.GDMonsterObjects1[i].getBehavior("MonsterEnemy").IsOnFire(null)) ) {
        isConditionTrue_0 = true;
        gdjs.Level2Code.GDMonsterObjects1[k] = gdjs.Level2Code.GDMonsterObjects1[i];
        ++k;
    }
}
gdjs.Level2Code.GDMonsterObjects1.length = k;
if (isConditionTrue_0) {

{ //Subevents
gdjs.Level2Code.eventsList13(runtimeScene);} //End of subevents
}

}


};gdjs.Level2Code.eventsList15 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Monster"), gdjs.Level2Code.GDMonsterObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level2Code.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDPlayerObjects1Objects, gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDMonsterObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {

{ //Subevents
gdjs.Level2Code.eventsList14(runtimeScene);} //End of subevents
}

}


};gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Level2Code.GDPlayerObjects2});
gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDPortalObjects2Objects = Hashtable.newFrom({"Portal": gdjs.Level2Code.GDPortalObjects2});
gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Level2Code.GDPlayerObjects2});
gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDPortalObjects2Objects = Hashtable.newFrom({"Portal": gdjs.Level2Code.GDPortalObjects2});
gdjs.Level2Code.eventsList16 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
/* Reuse gdjs.Level2Code.GDPlayerObjects2 */
/* Reuse gdjs.Level2Code.GDPortalObjects2 */
{for(var i = 0, len = gdjs.Level2Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level2Code.GDPlayerObjects2[i].activateBehavior("PlatformerObject", false);
}
}
{gdjs.evtsExt__Player__AnimateFallingIntoPortal.func(runtimeScene, gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDPlayerObjects2Objects, "Tween", gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDPortalObjects2Objects, null);
}
}

}


};gdjs.Level2Code.eventsList17 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(23018732);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("GameOverDialog"), gdjs.Level2Code.GDGameOverDialogObjects2);
{for(var i = 0, len = gdjs.Level2Code.GDGameOverDialogObjects2.length ;i < len;++i) {
    gdjs.Level2Code.GDGameOverDialogObjects2[i].SetScore(runtimeScene.getScene().getVariables().getFromIndex(0).getAsNumber(), null);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("GameOverDialog"), gdjs.Level2Code.GDGameOverDialogObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level2Code.GDGameOverDialogObjects2.length;i<l;++i) {
    if ( gdjs.Level2Code.GDGameOverDialogObjects2[i].IsRetryClicked(null) ) {
        isConditionTrue_0 = true;
        gdjs.Level2Code.GDGameOverDialogObjects2[k] = gdjs.Level2Code.GDGameOverDialogObjects2[i];
        ++k;
    }
}
gdjs.Level2Code.GDGameOverDialogObjects2.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, gdjs.evtTools.runtimeScene.getSceneName(runtimeScene), false);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("GameOverDialog"), gdjs.Level2Code.GDGameOverDialogObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level2Code.GDGameOverDialogObjects1.length;i<l;++i) {
    if ( gdjs.Level2Code.GDGameOverDialogObjects1[i].IsNextClicked(null) ) {
        isConditionTrue_0 = true;
        gdjs.Level2Code.GDGameOverDialogObjects1[k] = gdjs.Level2Code.GDGameOverDialogObjects1[i];
        ++k;
    }
}
gdjs.Level2Code.GDGameOverDialogObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Level2", false);
}
}

}


};gdjs.Level2Code.eventsList18 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.camera.layerIsVisible(runtimeScene, "EndScreen");
if (isConditionTrue_0) {

{ //Subevents
gdjs.Level2Code.eventsList17(runtimeScene);} //End of subevents
}

}


};gdjs.Level2Code.eventsList19 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.camera.hideLayer(runtimeScene, "EndScreen");
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level2Code.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("Portal"), gdjs.Level2Code.GDPortalObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDPlayerObjects2Objects, gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDPortalObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15222452);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.camera.showLayer(runtimeScene, "EndScreen");
}

{ //Subevents
gdjs.Level2Code.eventsList16(runtimeScene);} //End of subevents
}

}


{


gdjs.Level2Code.eventsList18(runtimeScene);
}


};gdjs.Level2Code.eventsList20 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("BoundaryJumpThrough"), gdjs.Level2Code.GDBoundaryJumpThroughObjects3);
gdjs.copyArray(runtimeScene.getObjects("LeftBoundary"), gdjs.Level2Code.GDLeftBoundaryObjects3);
gdjs.copyArray(runtimeScene.getObjects("RightBoundary"), gdjs.Level2Code.GDRightBoundaryObjects3);
{for(var i = 0, len = gdjs.Level2Code.GDLeftBoundaryObjects3.length ;i < len;++i) {
    gdjs.Level2Code.GDLeftBoundaryObjects3[i].hide();
}
for(var i = 0, len = gdjs.Level2Code.GDRightBoundaryObjects3.length ;i < len;++i) {
    gdjs.Level2Code.GDRightBoundaryObjects3[i].hide();
}
for(var i = 0, len = gdjs.Level2Code.GDBoundaryJumpThroughObjects3.length ;i < len;++i) {
    gdjs.Level2Code.GDBoundaryJumpThroughObjects3[i].hide();
}
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("BackgroundPlants"), gdjs.Level2Code.GDBackgroundPlantsObjects3);
gdjs.copyArray(runtimeScene.getObjects("Moon"), gdjs.Level2Code.GDMoonObjects3);
{for(var i = 0, len = gdjs.Level2Code.GDMoonObjects3.length ;i < len;++i) {
    gdjs.Level2Code.GDMoonObjects3[i].setPosition(0.9 * gdjs.evtTools.camera.getCameraWidth(runtimeScene, "", 0) - (( gdjs.Level2Code.GDBackgroundPlantsObjects3.length === 0 ) ? 0 :gdjs.Level2Code.GDBackgroundPlantsObjects3[0].getXOffset()),100 - (( gdjs.Level2Code.GDBackgroundPlantsObjects3.length === 0 ) ? 0 :gdjs.Level2Code.GDBackgroundPlantsObjects3[0].getYOffset()));
}
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("BottomBoundary"), gdjs.Level2Code.GDBottomBoundaryObjects2);
gdjs.copyArray(runtimeScene.getObjects("LeftBoundary"), gdjs.Level2Code.GDLeftBoundaryObjects2);
gdjs.copyArray(runtimeScene.getObjects("RightBoundary"), gdjs.Level2Code.GDRightBoundaryObjects2);
gdjs.copyArray(runtimeScene.getObjects("TopBoundary"), gdjs.Level2Code.GDTopBoundaryObjects2);
{gdjs.evtTools.camera.clampCamera(runtimeScene, (( gdjs.Level2Code.GDLeftBoundaryObjects2.length === 0 ) ? 0 :gdjs.Level2Code.GDLeftBoundaryObjects2[0].getPointX("")) + (( gdjs.Level2Code.GDLeftBoundaryObjects2.length === 0 ) ? 0 :gdjs.Level2Code.GDLeftBoundaryObjects2[0].getWidth()), (( gdjs.Level2Code.GDTopBoundaryObjects2.length === 0 ) ? 0 :gdjs.Level2Code.GDTopBoundaryObjects2[0].getPointY("")) + (( gdjs.Level2Code.GDTopBoundaryObjects2.length === 0 ) ? 0 :gdjs.Level2Code.GDTopBoundaryObjects2[0].getHeight()), (( gdjs.Level2Code.GDRightBoundaryObjects2.length === 0 ) ? 0 :gdjs.Level2Code.GDRightBoundaryObjects2[0].getPointX("")), (( gdjs.Level2Code.GDBottomBoundaryObjects2.length === 0 ) ? 0 :gdjs.Level2Code.GDBottomBoundaryObjects2[0].getPointY("")), "", 0);
}
}

}


};gdjs.Level2Code.eventsList21 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("ScoreText"), gdjs.Level2Code.GDScoreTextObjects2);
{for(var i = 0, len = gdjs.Level2Code.GDScoreTextObjects2.length ;i < len;++i) {
    gdjs.Level2Code.GDScoreTextObjects2[i].getBehavior("Text").setText("Score: " + gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(0)));
}
}
}

}


};gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDPortalObjects1Objects = Hashtable.newFrom({"Portal": gdjs.Level2Code.GDPortalObjects1});
gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.Level2Code.GDPlayerObjects1});
gdjs.Level2Code.eventsList22 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "crickets.aac", true, 30, 1);
}
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "door.aac", 0, true, 100, 1);
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level2Code.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("Portal"), gdjs.Level2Code.GDPortalObjects1);
{gdjs.evtsExt__VolumeFalloff__SetVolumeFalloff.func(runtimeScene, 0, "Sound", gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDPortalObjects1Objects, gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDPlayerObjects1Objects, 0, 20, 750, null);
}
}

}


};gdjs.Level2Code.eventsList23 = function(runtimeScene) {

{


gdjs.Level2Code.eventsList20(runtimeScene);
}


{


gdjs.Level2Code.eventsList21(runtimeScene);
}


{


gdjs.Level2Code.eventsList22(runtimeScene);
}


};gdjs.Level2Code.eventsList24 = function(runtimeScene) {

{


gdjs.Level2Code.eventsList4(runtimeScene);
}


{


gdjs.Level2Code.eventsList10(runtimeScene);
}


{


gdjs.Level2Code.eventsList12(runtimeScene);
}


{


gdjs.Level2Code.eventsList15(runtimeScene);
}


{


gdjs.Level2Code.eventsList19(runtimeScene);
}


{


gdjs.Level2Code.eventsList23(runtimeScene);
}


{


let isConditionTrue_0 = false;
{
}

}


};

gdjs.Level2Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Level2Code.GDGameOverDialogObjects1.length = 0;
gdjs.Level2Code.GDGameOverDialogObjects2.length = 0;
gdjs.Level2Code.GDGameOverDialogObjects3.length = 0;
gdjs.Level2Code.GDGameOverDialogObjects4.length = 0;
gdjs.Level2Code.GDPlayer2Objects1.length = 0;
gdjs.Level2Code.GDPlayer2Objects2.length = 0;
gdjs.Level2Code.GDPlayer2Objects3.length = 0;
gdjs.Level2Code.GDPlayer2Objects4.length = 0;
gdjs.Level2Code.GDPlatform1Objects1.length = 0;
gdjs.Level2Code.GDPlatform1Objects2.length = 0;
gdjs.Level2Code.GDPlatform1Objects3.length = 0;
gdjs.Level2Code.GDPlatform1Objects4.length = 0;
gdjs.Level2Code.GDPlatform2Objects1.length = 0;
gdjs.Level2Code.GDPlatform2Objects2.length = 0;
gdjs.Level2Code.GDPlatform2Objects3.length = 0;
gdjs.Level2Code.GDPlatform2Objects4.length = 0;
gdjs.Level2Code.GDPlatform3Objects1.length = 0;
gdjs.Level2Code.GDPlatform3Objects2.length = 0;
gdjs.Level2Code.GDPlatform3Objects3.length = 0;
gdjs.Level2Code.GDPlatform3Objects4.length = 0;
gdjs.Level2Code.GDPlatform4Objects1.length = 0;
gdjs.Level2Code.GDPlatform4Objects2.length = 0;
gdjs.Level2Code.GDPlatform4Objects3.length = 0;
gdjs.Level2Code.GDPlatform4Objects4.length = 0;
gdjs.Level2Code.GDPortalObjects1.length = 0;
gdjs.Level2Code.GDPortalObjects2.length = 0;
gdjs.Level2Code.GDPortalObjects3.length = 0;
gdjs.Level2Code.GDPortalObjects4.length = 0;
gdjs.Level2Code.GDCheckpointObjects1.length = 0;
gdjs.Level2Code.GDCheckpointObjects2.length = 0;
gdjs.Level2Code.GDCheckpointObjects3.length = 0;
gdjs.Level2Code.GDCheckpointObjects4.length = 0;
gdjs.Level2Code.GDLadderObjects1.length = 0;
gdjs.Level2Code.GDLadderObjects2.length = 0;
gdjs.Level2Code.GDLadderObjects3.length = 0;
gdjs.Level2Code.GDLadderObjects4.length = 0;
gdjs.Level2Code.GDMonsterObjects1.length = 0;
gdjs.Level2Code.GDMonsterObjects2.length = 0;
gdjs.Level2Code.GDMonsterObjects3.length = 0;
gdjs.Level2Code.GDMonsterObjects4.length = 0;
gdjs.Level2Code.GDFlyObjects1.length = 0;
gdjs.Level2Code.GDFlyObjects2.length = 0;
gdjs.Level2Code.GDFlyObjects3.length = 0;
gdjs.Level2Code.GDFlyObjects4.length = 0;
gdjs.Level2Code.GDCoinObjects1.length = 0;
gdjs.Level2Code.GDCoinObjects2.length = 0;
gdjs.Level2Code.GDCoinObjects3.length = 0;
gdjs.Level2Code.GDCoinObjects4.length = 0;
gdjs.Level2Code.GDMonsterParticlesObjects1.length = 0;
gdjs.Level2Code.GDMonsterParticlesObjects2.length = 0;
gdjs.Level2Code.GDMonsterParticlesObjects3.length = 0;
gdjs.Level2Code.GDMonsterParticlesObjects4.length = 0;
gdjs.Level2Code.GDCoinParticlesObjects1.length = 0;
gdjs.Level2Code.GDCoinParticlesObjects2.length = 0;
gdjs.Level2Code.GDCoinParticlesObjects3.length = 0;
gdjs.Level2Code.GDCoinParticlesObjects4.length = 0;
gdjs.Level2Code.GDDoorParticlesObjects1.length = 0;
gdjs.Level2Code.GDDoorParticlesObjects2.length = 0;
gdjs.Level2Code.GDDoorParticlesObjects3.length = 0;
gdjs.Level2Code.GDDoorParticlesObjects4.length = 0;
gdjs.Level2Code.GDDustParticleObjects1.length = 0;
gdjs.Level2Code.GDDustParticleObjects2.length = 0;
gdjs.Level2Code.GDDustParticleObjects3.length = 0;
gdjs.Level2Code.GDDustParticleObjects4.length = 0;
gdjs.Level2Code.GDCloudsObjects1.length = 0;
gdjs.Level2Code.GDCloudsObjects2.length = 0;
gdjs.Level2Code.GDCloudsObjects3.length = 0;
gdjs.Level2Code.GDCloudsObjects4.length = 0;
gdjs.Level2Code.GDScoreTextObjects1.length = 0;
gdjs.Level2Code.GDScoreTextObjects2.length = 0;
gdjs.Level2Code.GDScoreTextObjects3.length = 0;
gdjs.Level2Code.GDScoreTextObjects4.length = 0;
gdjs.Level2Code.GDBackgroundPlantsObjects1.length = 0;
gdjs.Level2Code.GDBackgroundPlantsObjects2.length = 0;
gdjs.Level2Code.GDBackgroundPlantsObjects3.length = 0;
gdjs.Level2Code.GDBackgroundPlantsObjects4.length = 0;
gdjs.Level2Code.GDLeftBoundaryObjects1.length = 0;
gdjs.Level2Code.GDLeftBoundaryObjects2.length = 0;
gdjs.Level2Code.GDLeftBoundaryObjects3.length = 0;
gdjs.Level2Code.GDLeftBoundaryObjects4.length = 0;
gdjs.Level2Code.GDRightBoundaryObjects1.length = 0;
gdjs.Level2Code.GDRightBoundaryObjects2.length = 0;
gdjs.Level2Code.GDRightBoundaryObjects3.length = 0;
gdjs.Level2Code.GDRightBoundaryObjects4.length = 0;
gdjs.Level2Code.GDTopBoundaryObjects1.length = 0;
gdjs.Level2Code.GDTopBoundaryObjects2.length = 0;
gdjs.Level2Code.GDTopBoundaryObjects3.length = 0;
gdjs.Level2Code.GDTopBoundaryObjects4.length = 0;
gdjs.Level2Code.GDBottomBoundaryObjects1.length = 0;
gdjs.Level2Code.GDBottomBoundaryObjects2.length = 0;
gdjs.Level2Code.GDBottomBoundaryObjects3.length = 0;
gdjs.Level2Code.GDBottomBoundaryObjects4.length = 0;
gdjs.Level2Code.GDBoundaryJumpThroughObjects1.length = 0;
gdjs.Level2Code.GDBoundaryJumpThroughObjects2.length = 0;
gdjs.Level2Code.GDBoundaryJumpThroughObjects3.length = 0;
gdjs.Level2Code.GDBoundaryJumpThroughObjects4.length = 0;
gdjs.Level2Code.GDMoonObjects1.length = 0;
gdjs.Level2Code.GDMoonObjects2.length = 0;
gdjs.Level2Code.GDMoonObjects3.length = 0;
gdjs.Level2Code.GDMoonObjects4.length = 0;
gdjs.Level2Code.GDEndScreenRetryTextObjects1.length = 0;
gdjs.Level2Code.GDEndScreenRetryTextObjects2.length = 0;
gdjs.Level2Code.GDEndScreenRetryTextObjects3.length = 0;
gdjs.Level2Code.GDEndScreenRetryTextObjects4.length = 0;
gdjs.Level2Code.GDJoystickObjects1.length = 0;
gdjs.Level2Code.GDJoystickObjects2.length = 0;
gdjs.Level2Code.GDJoystickObjects3.length = 0;
gdjs.Level2Code.GDJoystickObjects4.length = 0;
gdjs.Level2Code.GDJumpButtonObjects1.length = 0;
gdjs.Level2Code.GDJumpButtonObjects2.length = 0;
gdjs.Level2Code.GDJumpButtonObjects3.length = 0;
gdjs.Level2Code.GDJumpButtonObjects4.length = 0;
gdjs.Level2Code.GDScreenOrientationCheckerObjects1.length = 0;
gdjs.Level2Code.GDScreenOrientationCheckerObjects2.length = 0;
gdjs.Level2Code.GDScreenOrientationCheckerObjects3.length = 0;
gdjs.Level2Code.GDScreenOrientationCheckerObjects4.length = 0;
gdjs.Level2Code.GDFlag_9595RedObjects1.length = 0;
gdjs.Level2Code.GDFlag_9595RedObjects2.length = 0;
gdjs.Level2Code.GDFlag_9595RedObjects3.length = 0;
gdjs.Level2Code.GDFlag_9595RedObjects4.length = 0;
gdjs.Level2Code.GDPlayerObjects1.length = 0;
gdjs.Level2Code.GDPlayerObjects2.length = 0;
gdjs.Level2Code.GDPlayerObjects3.length = 0;
gdjs.Level2Code.GDPlayerObjects4.length = 0;
gdjs.Level2Code.GDStatueObjects1.length = 0;
gdjs.Level2Code.GDStatueObjects2.length = 0;
gdjs.Level2Code.GDStatueObjects3.length = 0;
gdjs.Level2Code.GDStatueObjects4.length = 0;
gdjs.Level2Code.GDSpikesObjects1.length = 0;
gdjs.Level2Code.GDSpikesObjects2.length = 0;
gdjs.Level2Code.GDSpikesObjects3.length = 0;
gdjs.Level2Code.GDSpikesObjects4.length = 0;
gdjs.Level2Code.GDSky2Objects1.length = 0;
gdjs.Level2Code.GDSky2Objects2.length = 0;
gdjs.Level2Code.GDSky2Objects3.length = 0;
gdjs.Level2Code.GDSky2Objects4.length = 0;

gdjs.Level2Code.eventsList24(runtimeScene);
gdjs.Level2Code.GDGameOverDialogObjects1.length = 0;
gdjs.Level2Code.GDGameOverDialogObjects2.length = 0;
gdjs.Level2Code.GDGameOverDialogObjects3.length = 0;
gdjs.Level2Code.GDGameOverDialogObjects4.length = 0;
gdjs.Level2Code.GDPlayer2Objects1.length = 0;
gdjs.Level2Code.GDPlayer2Objects2.length = 0;
gdjs.Level2Code.GDPlayer2Objects3.length = 0;
gdjs.Level2Code.GDPlayer2Objects4.length = 0;
gdjs.Level2Code.GDPlatform1Objects1.length = 0;
gdjs.Level2Code.GDPlatform1Objects2.length = 0;
gdjs.Level2Code.GDPlatform1Objects3.length = 0;
gdjs.Level2Code.GDPlatform1Objects4.length = 0;
gdjs.Level2Code.GDPlatform2Objects1.length = 0;
gdjs.Level2Code.GDPlatform2Objects2.length = 0;
gdjs.Level2Code.GDPlatform2Objects3.length = 0;
gdjs.Level2Code.GDPlatform2Objects4.length = 0;
gdjs.Level2Code.GDPlatform3Objects1.length = 0;
gdjs.Level2Code.GDPlatform3Objects2.length = 0;
gdjs.Level2Code.GDPlatform3Objects3.length = 0;
gdjs.Level2Code.GDPlatform3Objects4.length = 0;
gdjs.Level2Code.GDPlatform4Objects1.length = 0;
gdjs.Level2Code.GDPlatform4Objects2.length = 0;
gdjs.Level2Code.GDPlatform4Objects3.length = 0;
gdjs.Level2Code.GDPlatform4Objects4.length = 0;
gdjs.Level2Code.GDPortalObjects1.length = 0;
gdjs.Level2Code.GDPortalObjects2.length = 0;
gdjs.Level2Code.GDPortalObjects3.length = 0;
gdjs.Level2Code.GDPortalObjects4.length = 0;
gdjs.Level2Code.GDCheckpointObjects1.length = 0;
gdjs.Level2Code.GDCheckpointObjects2.length = 0;
gdjs.Level2Code.GDCheckpointObjects3.length = 0;
gdjs.Level2Code.GDCheckpointObjects4.length = 0;
gdjs.Level2Code.GDLadderObjects1.length = 0;
gdjs.Level2Code.GDLadderObjects2.length = 0;
gdjs.Level2Code.GDLadderObjects3.length = 0;
gdjs.Level2Code.GDLadderObjects4.length = 0;
gdjs.Level2Code.GDMonsterObjects1.length = 0;
gdjs.Level2Code.GDMonsterObjects2.length = 0;
gdjs.Level2Code.GDMonsterObjects3.length = 0;
gdjs.Level2Code.GDMonsterObjects4.length = 0;
gdjs.Level2Code.GDFlyObjects1.length = 0;
gdjs.Level2Code.GDFlyObjects2.length = 0;
gdjs.Level2Code.GDFlyObjects3.length = 0;
gdjs.Level2Code.GDFlyObjects4.length = 0;
gdjs.Level2Code.GDCoinObjects1.length = 0;
gdjs.Level2Code.GDCoinObjects2.length = 0;
gdjs.Level2Code.GDCoinObjects3.length = 0;
gdjs.Level2Code.GDCoinObjects4.length = 0;
gdjs.Level2Code.GDMonsterParticlesObjects1.length = 0;
gdjs.Level2Code.GDMonsterParticlesObjects2.length = 0;
gdjs.Level2Code.GDMonsterParticlesObjects3.length = 0;
gdjs.Level2Code.GDMonsterParticlesObjects4.length = 0;
gdjs.Level2Code.GDCoinParticlesObjects1.length = 0;
gdjs.Level2Code.GDCoinParticlesObjects2.length = 0;
gdjs.Level2Code.GDCoinParticlesObjects3.length = 0;
gdjs.Level2Code.GDCoinParticlesObjects4.length = 0;
gdjs.Level2Code.GDDoorParticlesObjects1.length = 0;
gdjs.Level2Code.GDDoorParticlesObjects2.length = 0;
gdjs.Level2Code.GDDoorParticlesObjects3.length = 0;
gdjs.Level2Code.GDDoorParticlesObjects4.length = 0;
gdjs.Level2Code.GDDustParticleObjects1.length = 0;
gdjs.Level2Code.GDDustParticleObjects2.length = 0;
gdjs.Level2Code.GDDustParticleObjects3.length = 0;
gdjs.Level2Code.GDDustParticleObjects4.length = 0;
gdjs.Level2Code.GDCloudsObjects1.length = 0;
gdjs.Level2Code.GDCloudsObjects2.length = 0;
gdjs.Level2Code.GDCloudsObjects3.length = 0;
gdjs.Level2Code.GDCloudsObjects4.length = 0;
gdjs.Level2Code.GDScoreTextObjects1.length = 0;
gdjs.Level2Code.GDScoreTextObjects2.length = 0;
gdjs.Level2Code.GDScoreTextObjects3.length = 0;
gdjs.Level2Code.GDScoreTextObjects4.length = 0;
gdjs.Level2Code.GDBackgroundPlantsObjects1.length = 0;
gdjs.Level2Code.GDBackgroundPlantsObjects2.length = 0;
gdjs.Level2Code.GDBackgroundPlantsObjects3.length = 0;
gdjs.Level2Code.GDBackgroundPlantsObjects4.length = 0;
gdjs.Level2Code.GDLeftBoundaryObjects1.length = 0;
gdjs.Level2Code.GDLeftBoundaryObjects2.length = 0;
gdjs.Level2Code.GDLeftBoundaryObjects3.length = 0;
gdjs.Level2Code.GDLeftBoundaryObjects4.length = 0;
gdjs.Level2Code.GDRightBoundaryObjects1.length = 0;
gdjs.Level2Code.GDRightBoundaryObjects2.length = 0;
gdjs.Level2Code.GDRightBoundaryObjects3.length = 0;
gdjs.Level2Code.GDRightBoundaryObjects4.length = 0;
gdjs.Level2Code.GDTopBoundaryObjects1.length = 0;
gdjs.Level2Code.GDTopBoundaryObjects2.length = 0;
gdjs.Level2Code.GDTopBoundaryObjects3.length = 0;
gdjs.Level2Code.GDTopBoundaryObjects4.length = 0;
gdjs.Level2Code.GDBottomBoundaryObjects1.length = 0;
gdjs.Level2Code.GDBottomBoundaryObjects2.length = 0;
gdjs.Level2Code.GDBottomBoundaryObjects3.length = 0;
gdjs.Level2Code.GDBottomBoundaryObjects4.length = 0;
gdjs.Level2Code.GDBoundaryJumpThroughObjects1.length = 0;
gdjs.Level2Code.GDBoundaryJumpThroughObjects2.length = 0;
gdjs.Level2Code.GDBoundaryJumpThroughObjects3.length = 0;
gdjs.Level2Code.GDBoundaryJumpThroughObjects4.length = 0;
gdjs.Level2Code.GDMoonObjects1.length = 0;
gdjs.Level2Code.GDMoonObjects2.length = 0;
gdjs.Level2Code.GDMoonObjects3.length = 0;
gdjs.Level2Code.GDMoonObjects4.length = 0;
gdjs.Level2Code.GDEndScreenRetryTextObjects1.length = 0;
gdjs.Level2Code.GDEndScreenRetryTextObjects2.length = 0;
gdjs.Level2Code.GDEndScreenRetryTextObjects3.length = 0;
gdjs.Level2Code.GDEndScreenRetryTextObjects4.length = 0;
gdjs.Level2Code.GDJoystickObjects1.length = 0;
gdjs.Level2Code.GDJoystickObjects2.length = 0;
gdjs.Level2Code.GDJoystickObjects3.length = 0;
gdjs.Level2Code.GDJoystickObjects4.length = 0;
gdjs.Level2Code.GDJumpButtonObjects1.length = 0;
gdjs.Level2Code.GDJumpButtonObjects2.length = 0;
gdjs.Level2Code.GDJumpButtonObjects3.length = 0;
gdjs.Level2Code.GDJumpButtonObjects4.length = 0;
gdjs.Level2Code.GDScreenOrientationCheckerObjects1.length = 0;
gdjs.Level2Code.GDScreenOrientationCheckerObjects2.length = 0;
gdjs.Level2Code.GDScreenOrientationCheckerObjects3.length = 0;
gdjs.Level2Code.GDScreenOrientationCheckerObjects4.length = 0;
gdjs.Level2Code.GDFlag_9595RedObjects1.length = 0;
gdjs.Level2Code.GDFlag_9595RedObjects2.length = 0;
gdjs.Level2Code.GDFlag_9595RedObjects3.length = 0;
gdjs.Level2Code.GDFlag_9595RedObjects4.length = 0;
gdjs.Level2Code.GDPlayerObjects1.length = 0;
gdjs.Level2Code.GDPlayerObjects2.length = 0;
gdjs.Level2Code.GDPlayerObjects3.length = 0;
gdjs.Level2Code.GDPlayerObjects4.length = 0;
gdjs.Level2Code.GDStatueObjects1.length = 0;
gdjs.Level2Code.GDStatueObjects2.length = 0;
gdjs.Level2Code.GDStatueObjects3.length = 0;
gdjs.Level2Code.GDStatueObjects4.length = 0;
gdjs.Level2Code.GDSpikesObjects1.length = 0;
gdjs.Level2Code.GDSpikesObjects2.length = 0;
gdjs.Level2Code.GDSpikesObjects3.length = 0;
gdjs.Level2Code.GDSpikesObjects4.length = 0;
gdjs.Level2Code.GDSky2Objects1.length = 0;
gdjs.Level2Code.GDSky2Objects2.length = 0;
gdjs.Level2Code.GDSky2Objects3.length = 0;
gdjs.Level2Code.GDSky2Objects4.length = 0;


return;

}

gdjs['Level2Code'] = gdjs.Level2Code;
